

<?php $__env->startSection('title',"Editar Alumno"); ?>

<?php $__env->startSection('contenido'); ?>
<h3>
    Editando alumno <i><?php echo e($alumno->matricula); ?></i>
</h3>
<form action="<?php echo e(route('alumno.update',$alumno)); ?>" method="POST">
    <?php echo method_field('put'); ?>
   <?php if (isset($component)) { $__componentOriginal034c77f185d647c6943259d9788fb42eabac5d34 = $component; } ?>
<?php $component = App\View\Components\AlumnoFormBody::resolve(['alumno' => $alumno] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alumno-form-body'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AlumnoFormBody::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal034c77f185d647c6943259d9788fb42eabac5d34)): ?>
<?php $component = $__componentOriginal034c77f185d647c6943259d9788fb42eabac5d34; ?>
<?php unset($__componentOriginal034c77f185d647c6943259d9788fb42eabac5d34); ?>
<?php endif; ?>
</form>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tema.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema\resources\views/alumno/edit.blade.php ENDPATH**/ ?>