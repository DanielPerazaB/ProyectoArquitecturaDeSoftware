

<?php $__env->startSection('title',"Listado Alumnos"); ?>

<?php $__env->startSection('contenido'); ?>
<h3>
  Listado de los alumnos registrados
</h3>
<table class="table table-stripped table-hover">
    <thead>
        <tr>
            <th>
                Matrícula
            </th>
            <th>
                Nombre Completo
            </th>
            <th>
                Correo electrónico
            </th>
            <th>
                Teléfono
            </th>
            <th>
                Edad
            </th>
            <th>
                Opciones
            </th>
        </tr>
    </thead>
    <tbody>
      
        <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($alumno->matricula); ?>

                </td>
                <td>
                    <?php echo e($alumno->nombreCompleto); ?>

                </td>
                <td>
                    <?php echo e($alumno->correoElectronico); ?>

                </td>
                <td>
                    <?php echo e($alumno->numeroTelefonico); ?>

                </td>
                <td>
                    <?php echo e($alumno->edad); ?>

                </td>
                <td>
                   <a href="<?php echo e(route('alumno.edit',$alumno)); ?>">Editar</a>
                   <a href="<?php echo e(route('alumno.show',$alumno)); ?>">Ver</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tema.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema\resources\views/alumno/index.blade.php ENDPATH**/ ?>