<?php $__env->startSection('title',"Inicio"); ?>

<?php $__env->startSection('contenido'); ?>
<h3>
    Bienvenido al sistema
</h3>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tema.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema\resources\views/welcome.blade.php ENDPATH**/ ?>