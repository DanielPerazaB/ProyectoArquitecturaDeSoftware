

<?php $__env->startSection('title',"Información del Alumno"); ?>

<?php $__env->startSection('contenido'); ?>
<h3>
    Alumno: <i><?php echo e($alumno->matricula); ?></i>
</h3>
<ul>
    <li>
        Nombre completo: <strong><?php echo e($alumno->nombreCompleto); ?></strong>
    </li>
    <li>
        Correo electrónico: <strong><?php echo e($alumno->correoElectronico); ?></strong>
    </li>
    <li>
        Número telefónico: <strong><?php echo e($alumno->numeroTelefonico); ?></strong>
    </li>
    <li>
       Edad: <strong><?php echo e($alumno->edad); ?></strong>
    </li>
</ul>

<div class="row">
    <div class="col-sm-12 mb-2">
        <form action="<?php echo e(route('alumno.destroy',$alumno)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <button class=" btn btn-danger btn-sm" type="submit">Eliminar Alumno</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('tema.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema\resources\views/alumno/show.blade.php ENDPATH**/ ?>