@extends('tema.app')

@section('title',"Inicio")

@section('contenido')
<h3>
    Bienvenido al sistema
</h3>
@endsection
